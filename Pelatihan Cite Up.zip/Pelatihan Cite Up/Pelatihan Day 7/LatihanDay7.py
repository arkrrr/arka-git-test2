def hitung_total_nilai(nilai_tugas, nilai_ulangan, nilai_UTS, nilai_UAS):
    total_nilai = nilai_tugas + nilai_ulangan + nilai_UTS + nilai_UAS
    return total_nilai

def hitung_rata_rata(total_nilai, jumlah_penilaian):
    rata_rata = total_nilai / jumlah_penilaian
    return rata_rata

def konversi_ke_huruf(nilai_rata_rata):
    if nilai_rata_rata >= 80:
        return "A"
    elif nilai_rata_rata >= 75:
        return "A-"
    elif nilai_rata_rata >= 70:
        return "B+"
    elif nilai_rata_rata >= 65:
        return "B"
    elif nilai_rata_rata >= 60:
        return "B-"
    elif nilai_rata_rata >= 55:
        return "C+"
    elif nilai_rata_rata >= 50:
        return "C-"
    elif nilai_rata_rata >= 30:
        return "D"
    else:
        return "E"


jumlah_penilaian = 4

nilai_tugas = float(input("Masukkan nilai tugas: "))
nilai_ulangan = float(input("Masukkan nilai ulangan: "))
nilai_UTS = float(input("Masukkan nilai UTS: "))
nilai_UAS= float(input("Masukkan nilai UAS: "))

total_nilai = hitung_total_nilai(nilai_tugas, nilai_ulangan, nilai_UTS, nilai_UAS)
rata_rata = hitung_rata_rata(total_nilai, jumlah_penilaian)

print("Total nilai: {:.2f}".format(total_nilai))
print("Rata-rata: {:.2f}".format(rata_rata))

nilai_huruf = konversi_ke_huruf(rata_rata)
# print("Nilai huruf: {}".format(nilai_huruf))
print(f"Nilai huruf: {nilai_huruf}")

