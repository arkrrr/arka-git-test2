# Belajar Mengenal list

#List -> kumpulan data
data_angka = [1,5,2,10]
print(data_angka)

#kumpulan data string
data_string = ["farhan", "hafiz", "michael"]
print(data_string)

#kumpulan data campuran
data_campuran = [1,"balball",True,False,10.5]
print(data_campuran)

data_range = range(0,10,2)
print(data_range)
data_list = list(data_range)
print(data_list)

list_menggunakan_for = [i*2 for i in range(0, 10)]
print(list_menggunakan_for)

list_angka_genap = [i for i in range(0,10) if i%2 == 0]
print(list_angka_genap)

list_angka_ganjil = [i for i in range(0,10) if i%2 == 1]
print(list_angka_ganjil)

#Manipulasi pada list

#index        0(-3)       1(-2)        2(-1)      
data = ["Nasi Goreng", "Nasi Uduk", "Bubur Ayam"]

print(f"data[:2] = {data[:2]}")
print(f"data[:-3] = {data[:-3]}")

data_0 = data[0]
print(f"data pertama (index 0) = {data_0}")


data_terakhir = data[-1]
print(f"data pertama (index 0) = {data_terakhir}")

panjang_data = len(data)
print(f"panjang data = {panjang_data}")

data.insert(2,"Sop Buntut")
print(f"data setelah di tambah \n{data}")

data.append("Sate Madura")
print(f"data setelah di tambah index terakhir \n{data}")

new_data = ["Sate Taichan", "Ayam Goreng"]
data.extend(new_data)
print(f"data gabungan = \n{data}")

data[1] = "Pizza"
print(f"data baru = \n{data}")

data.remove("Pizza")
print(f"data setelah diubah = \n{data}")

data.pop()
print(f"data akhir = \n {data}")

#Operasi pada list
data_baru = [1,1,1,23,4,5,3,6,10,66,43,42,12]

jumlah_4 = data_baru.count(4)
jumlah_1 = data_baru.count(1)
print(jumlah_1)

index_BuburAyam = data.index("Bubur Ayam")
print(f"Bubur Ayam berada di index = {index_BuburAyam}")

data_baru.sort()
print(f"data ter urutnya adalah {data_baru}")

data_baru.reverse()
print(f"data ter urutnya adalah {data_baru}")


#Balik Ke Perulangan

angka_Perulangan = [i*2 for i in range(0, 10)]

for i in angka_Perulangan:
    print(f"angka saat ini -> {i}")

#Nested Loop
for i in range(5,0,-1):
    for j in range(i):
        print("*", end="")
    print()

'''
buat bentuk seperti ini:
    *
   ***
  *****
 *******
*********
'''
# print('berbuat baik\nbagi sesama')
print('\n')
for i in range(5):
    for j in range(5-(i-1)):
        print(" ",end="")
    for j in range(2*i + 1):
        print("*", end="")
    print()
'''
perulangan 1 =
i = 0
j = 4

perulangan 2 = 
i = 1
j = 3

perulangan 3 = 
i = 2
j = 2

'''


