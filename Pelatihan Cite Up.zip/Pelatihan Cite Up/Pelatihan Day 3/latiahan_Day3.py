print("Hello world")

print("'C:\Fileku'")


print("mari kita menunaikan sholat jum'at")

print('mari kita menunaikan sholat jum\'at')


nama = "farhan"
print(f"selamat pagi {nama}, semoga harimu menyenangkan")
print("Selamat pagi ", nama, "semoga harimu menyenangkan")

nama_lengkap = f"{nama} dwi septian"

print(nama_lengkap)

print(r'C:\new folder')

'''
\n = newLine
\t = tab


'''

# suhu = -2
# if(suhu <= 0):
#     print("Beku")
#     print("blbalbal")
# else:
#     print("Cair")

#perulangan

#while loop

# while kondisi:
# 	aksi ini
# 	aksi itu

# akhir dari program

angka = 0

while angka<11:
    angka = angka + 1
    print("angka sekarang => ", angka)

#for loop
#0,1,2,3
angka2 = range(10, 0, -1)
print(angka2)
i = 10
for _ in angka2:
    i *= 2
    print(i)
    i -= 1

for i in range(10):
    print("hello world")


#fungsi dalam python

#1. build-in function
'''
print()
sort()

'''

#2. user-define function

#def nama_fungsi():
#aksi
#return (fungsi kembalian)

# x = y**2 + 2 => f(3) = 11

# def ini_fungsi(y):
#     x = y**2 + 2
#     return x

# hasil = ini_fungsi(3)
# print(hasil)

# def menghitungHargaAyam(kg):
#     hargaTotal = 10000 * kg
#     print(hargaTotal)

# menghitungHargaAyam(30)
