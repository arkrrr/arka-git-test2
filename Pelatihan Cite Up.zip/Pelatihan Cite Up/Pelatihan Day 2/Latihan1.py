

variabel1 = 10
variabel2 = 3
variabel3 = "ini variabel string"
variabel4 = 2.5
variabel5 = "10"
variabel6 = True
 
#ini operator tambah '+'
print("Menggunakan operator +")
print(variabel1 + variabel4)

#ini operator ,
print("\nMenggunakan operator ,")
print(variabel1 , variabel3)

#ini operator //
print("\nMenggunakan operator //")
print(variabel1//variabel2)


#ini operator %
print("\nMenggunakan operator %")
print(variabel1%variabel2)


#ini operator %
print("\nMenggunakan operator **")
print(variabel1**variabel2)

#Menggunakan operator komparasi

#Menggunakan operator ==
print("\nMenggunakan operator ==")
print(variabel1==variabel5)

#Menggunakan operator !=
print("\nMenggunakan operator !=")
print(variabel1!=variabel2)

#Menggunakan operator !=
print("\nMenggunakan operator !=")
print(variabel1!=variabel2)

#Menggunakan operator ~
print("\nMenggunakan operator ~")
print(~variabel6)


#Menggunakan operator -=
# variabel1 += 10 => variabel1 = variabel1 + 10
print("\nMenggunakan operator -=")
variabel1 -= 5
print(variabel1)

#Menggunakan operator Logika and
# variabel1 += 10 => variabel1 = variabel1 + 10
boolean1 = True
boolean2 = True
print("\nMenggunakan operator and")

print(boolean1 and boolean2)

#Menggunakan operator Logika or
# variabel1 += 10 => variabel1 = variabel1 + 10
boolean1 = True
boolean2 = False
print("\nMenggunakan operator or")

print(boolean1 or boolean2)

#cara comment multiline
'''kdjf
dkjdjf
jdkfj
dfjkdfjdk
jdkfjd
kdkjfkdj'''

#Pengkondisian If Else
print("\nMenggunakan if else\n")
uang = 6000
if uang >= 6000:
    print("uang cukup :D")
else:
    print("uang tidak cukup :(")


#Pengkondisian If Else
#else if => elif
print("\nMenggunakan if else\n")
uang = 10000
if uang >= 100000:
    print("uangmu banyak")
elif uang>=50000 and uang<100000:
    print("Uangmu sedang")
elif uang<50000:
    print("uangmu sedikit")

#Buatlah sebuah program dalam bentuk flowchart/pseudocode yang menerima suhu air (dalam derajat celcius) dan menuliskan wujud air ke layar sebagai berikut: 
#Jika suhu air <= 0 derajat, maka tuliskan “beku”, jika tidak maka "cair" 

suhu = int(input("Masukkan suhu: "))
print(suhu)
if suhu <= 0:
    print("beku")
else:
    print("cair")

#casting tipe data
print("\nCasting tipe data")
a = 10
b = 3
c = a/b
print(int(c))



