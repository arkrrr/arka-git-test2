import sys
import timeit
# Fungsi Rekursive
# fungsi yang didalamnya memanggil fungsi dirinya sendiri

# menghitung faktorial

# 5! = 5 * 4 * 3 * 2 * 1

def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)
    
print(factorial(5))

'''
n = 5
factorial(5)
5 * factorial(4)
       4 * factorial(3)
                3 * factorial(2)
                         2 * factorial(1)
                                 1 * factorial(0)
                                         1 * 1
'''

# Menghitung deret fibonacci

# deret yang menjumlahkan 2 angka sebelumnya 

# contoh deret fibonacci = 0, 1, 1, 2, 3, 5, 8, 13, ...


def fibonacci(n):
    fib = [0,1]
    if n < 0:
        return "Masukkan bilangan bulat positif"
    elif n == 1:
        return fib[:1]
    elif n == 2:
        return fib
    
    for i in range(2,n):
        fib_selanjutnya = fib[-1] + fib[-2]
        fib.append(fib_selanjutnya)

    return fib
    
print(fibonacci(5))

'''
n = 5(posisi) => 3
n-1 = 4(posisi) => 2
n-2 = 3(posisi) => 1
1 + 0 = 1

'''

# Latihan List

# Program untuk list buku

list_buku = []

'''

while True:
    print("Masukan data buku")
    judul = input("Judul buku\t: ")
    penulis = input("Nama penulis\t: ")

    list_baru = [judul, penulis]
    list_buku.append(list_baru)

    print("\n", "=" * 30)
    for index,buku in enumerate(list_buku):
        print(f"{index+1} | {buku[0]} | {buku[1]}")
    
    print("\n", "*"*30)
    isLanjut = input("Apakah anda ingin meneruskan program?(y/n) ")
    
    if isLanjut == 'n':
        break
    else:
        continue

'''
# Tuple

# list
bilangan_ganjil = [1,3,5,7]

# Tuple
bilangan_genap = (2,4,6,8)

# cara mengubah menjadi tuple
bilangan_ganjil = tuple(bilangan_ganjil)

print(bilangan_ganjil)
print(bilangan_genap)

print(type(bilangan_ganjil))
print(type(bilangan_genap))

besar_dataList = sys.getsizeof(bilangan_ganjil)
besar_dataTuple = sys.getsizeof(bilangan_genap)
print(besar_dataList)
print(besar_dataTuple)

data_list = timeit.timeit(stmt="[1,2,3,4,5,6,7,8,9]", number = 1000000)
data_tuple = timeit.timeit(stmt="(1,2,3,4,5,6,7,8,9)", number = 1000000)

print(f"Waktu untuk pengeksekuisan list: ", data_list)
print(f"Waktu untuk pengeksekuisan tuple: ", data_tuple)

# Tipe dictionary

member1 = {"ID":1,"Nama":"Jilan", "Status":"Pelajar"}

print(member1)
print(member1.keys())
print(member1.items())

