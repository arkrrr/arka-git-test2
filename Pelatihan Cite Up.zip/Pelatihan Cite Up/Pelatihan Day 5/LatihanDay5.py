import copy
# Build in function
# sort()
# print()


# Fungsi memiliki 2 tipe:
# 1. fungsi dengan nilai kembalian -> return value
# 2. fungsi dengan tanpa nilai kembalian -> void, prosedur


# kita melakukan fungsi dengan tanpa nilai kembalian
# def nama_function():
#     isi_function

def suara():
    print("kukuruyuk!")

# def harga():
#     print("Harga ayam per 1 kg adalah Rp 15.000")

def hargaTotalAyam(kilogram, harga):
    harga = 30000
    print(f"Harga ayam {harga}, seberat {kilogram} kilogram")


kg = 10
harga = 20000
hargaTotalAyam(kg, harga)
print(harga)
print('+'*40)
# Fungsi dengan nilai kembalian

# y = x**2 + 2 +3x;

def kuadrat(x):
    total = x**2
    print(f'nilai kuadrat dari {x} adalah {total}')
    return total

def mengalikan2Bilangan(parameter1, parameter2):
    total = parameter1 * parameter2
    return total

menghitung_Kuadrat = kuadrat(11)
print(menghitung_Kuadrat)
kali = mengalikan2Bilangan(4,10)
print(kali)

print('+'*40)

# membuat lambda function
# anonymous function
kali = lambda x,y:x*y
print(kali(2,4))

print('+'*40)

print('\n')

def piramida(tinggi):
    for i in range(tinggi):
        for _ in range(tinggi-(i-1)):
            print(" ",end="")
        for _ in range(2*i + 1):
            print("*", end="")
        print()

piramida(10)
piramida(8)
piramida(5)


# Variabel scope
# Variabel scope tipenya ada 2:
# 1. block scope -> java,
# 2. functional scope -> c++, python

# scope global bisa di gunakan untuk bersama
# scope local hanya bisa di gunakan untuk scope tertentu saja

# variabel local
namaKucing = "Kettie"
def mengubahNamaKucing(namaBaru):
    namaKucing = namaBaru
    print(f'nama baru kucing adalah {namaKucing}')
    while(True):
        namafungsi="scope variabel"
        i = 5
        print(f"tes variabel scope, nilai i adalah {i}")
        if(i == 5):
            break
    print(namafungsi)

# variabel global
def ubahNama(namaBaru):
    global namaKucing
    namaKucing = namaBaru

mengubahNamaKucing('cassandra')
print(f'variabel local\nnama kucing saya menjadi {namaKucing}')
ubahNama('zeus')
print(f'variabel global\nnama kucing saya menjadi {namaKucing}')



# NESTED LIST
data0 = [1,2,3]
data1 = [4,5,6]

data_list = [data0,data1]
print(data_list)

# implementasi
peserta1 = ["Michael", 18, "Laki-laki"]
peserta2 = ["Farhan", 20, "Laki-laki"]
peserta3 = ["Sinta", 18, "Perempuan"]

list_peserta = [peserta1,peserta2,peserta3]
print(f"peserta = {list_peserta}")

for peserta in list_peserta:

    print(f"nama\t: {peserta[0]}")
    print(f"umur\t: {peserta[1]}")
    print(f"gender\t: {peserta[2]}\n")

# copy()
list_copy = copy.deepcopy(list_peserta)
# list_copy = list_peserta.copy()
print(list_peserta[0][1])
list_copy[0][1] = 25
list_peserta[0][0] = "kang sule"
print(f"peserta = {list_copy}")
print(f"peserta = {list_peserta}")
